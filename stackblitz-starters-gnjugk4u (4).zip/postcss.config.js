module.exports = {
  plugins: {
    tailwindcss: {}, // Use 'tailwindcss' directly, not '@tailwindcss/postcss'
    autoprefixer: {},
  },
};