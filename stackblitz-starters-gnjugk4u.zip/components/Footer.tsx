export default function Footer() {
  return (
    <footer className="p-4 bg-gray-800 text-center text-white">
      <p>© 2025 My AI Platform. All rights reserved.</p>
    </footer>
  );
}
